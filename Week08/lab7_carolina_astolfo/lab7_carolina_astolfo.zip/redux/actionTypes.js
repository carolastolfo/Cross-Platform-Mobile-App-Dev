//operations allowed on the states

export const SET_CELSIUS = 'SET_CELSIUS';
