import { View, Text, FlatList } from "react-native"


const ScoreboardScreen = ( {navigation, route}) => {

    const {score} = route.params

    return (
        <View>
            <FlatList 
            data={score}
            keyExtractor={(item, index) => index.toString()}
            renderItem={ ({item}) => {
                <Text>{item} out of 5 games won!</Text>
            }}
            />
        </View>
    )
}

export default ScoreboardScreen